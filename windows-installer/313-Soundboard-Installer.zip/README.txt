313 SOUNDBOARD - TeamSpeak 6 Addon
====================================

INSTALL:
  1. Close TeamSpeak 6
  2. Double-click "Install 313 Soundboard.bat"
  3. Follow the prompts
  4. Restart TeamSpeak 6

ROOM CODE: 313

After install, you'll see an orange speaker button in the
bottom-right of TeamSpeak. Click it to open the soundboard.

UNINSTALL:
  The installer only modifies one file:
    TeamSpeak\html\client_ui\index.html
  To uninstall, reinstall/repair TeamSpeak or remove the
  addon block between the ADDON_START and ADDON_END comments.

TROUBLESHOOTING:
  - If the soundboard iframe doesn't load, you may need
    the binary patch. Install Java and run:
    TS6AddonInstaller-3.4.0-all.jar
  - If Windows blocks the .bat file, right-click it and
    select "Run as administrator"
